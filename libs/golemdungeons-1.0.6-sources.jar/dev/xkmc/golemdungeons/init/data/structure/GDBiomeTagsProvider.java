package dev.xkmc.golemdungeons.init.data.structure;

import dev.xkmc.golemdungeons.init.GolemDungeons;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.BiomeTagsProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BiomeTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraftforge.common.Tags;
import net.minecraftforge.common.data.ExistingFileHelper;

import java.util.concurrent.CompletableFuture;

public final class GDBiomeTagsProvider extends BiomeTagsProvider {

	public GDBiomeTagsProvider(PackOutput output, CompletableFuture<HolderLookup.Provider> pvd, ExistingFileHelper helper) {
		super(output, pvd, GolemDungeons.MODID, helper);
	}

	@Override
	protected void addTags(HolderLookup.Provider pvd) {
		tag(GDStructureGen.SCULK_FACTORY.biomes()).add(Biomes.DEEP_DARK);
		tag(GDStructureGen.PIGLIN_FACTORY.biomes()).add(Biomes.CRIMSON_FOREST);
		tag(GDStructureGen.ABANDONED_FACTORY.biomes()).addTag(Tags.Biomes.IS_PLAINS);
	}

	public static TagKey<Biome> asTag(String name) {
		return TagKey.create(Registries.BIOME, GolemDungeons.loc(name));
	}

	public static TagKey<Biome> forgeTag(String name) {
		return TagKey.create(Registries.BIOME, new ResourceLocation("forge", name));
	}

	public static TagKey<Biome> cTag(String name) {
		return TagKey.create(Registries.BIOME, new ResourceLocation("c", name));
	}

}